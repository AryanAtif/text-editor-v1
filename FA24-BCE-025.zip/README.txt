hello, sir, this program won't work on a windows machine because it has a completely different terminal and library for the terminal, and i haven't written it for windows. If you want to compile and run this program, i'd recommend you to run it on some linux/macOS machine or run it on window through WSL.

thanks,
Aryan Atif
